export const signUp_url = 'http://i11b109.p.ssafy.io:8080/sign-up';

export const signIn_url = '/login';

export const mm_url =
  'https://meeting.ssafy.com/hooks/ais9hkgenjfaiyu1jcb4tmkucy';
